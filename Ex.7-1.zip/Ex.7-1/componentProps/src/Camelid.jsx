// src/Camelid.jsx
import React from 'react';

const Camelid = ({ name, image, trivia }) => {
  return (
    <div className="camelid-card">
      <h2>{name}</h2>
      <img src={image} alt={name} style={{ width: '200px', height: 'auto' }} />
      <p>{trivia}</p>
    </div>
  );
};

export default Camelid;
