// src/App.jsx
import React from 'react';
import './App.css';  // Correct path if App.css is in the same folder as App.jsx
import Camelid from './Camelid';  // Import the Camelid component

function App() {
  const llama = {
    name: 'Llama',
    image: 'https://autogpt.net/wp-content/uploads/2023/08/Pogla_Dive_into_Code_Llama_Meta_Platforms_innovative_AI_tool_se_672579a4-772b-4fc7-9522-43026b62a2a4.jpg',  // Replace with actual llama image URL
    trivia: 'Llamas are known for their ability to carry heavy loads and their wool.',
  };

  const alpaca = {
    name: 'Alpaca',
    image: 'https://thumbs.dreamstime.com/b/happy-laughing-alpaca-sits-sofa-holds-laptop-his-hands-created-generative-ai-technology-who-dressed-317969444.jpg',  // Replace with actual alpaca image URL
    trivia: 'Alpacas are generally smaller and have softer wool than llamas.',
  };

  return (
    <div className="App">
      <h1>Camelid Comparison</h1>
      <Camelid name={llama.name} image={llama.image} trivia={llama.trivia} />
      <Camelid name={alpaca.name} image={alpaca.image} trivia={alpaca.trivia} />
    </div>
  );
}

export default App;