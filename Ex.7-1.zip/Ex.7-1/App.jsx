// src/App.jsx
import React from 'react';
import Camelid from './Camelid';  // Import the Camelid component
import './App.css';  // Import the CSS

function App() {
  const llama = {
    name: 'Llama',
    image: 'https://example.com/llama.jpg',  // Replace with actual llama image URL
    trivia: 'Llamas are known for their ability to carry heavy loads and their wool.',
  };

  const alpaca = {
    name: 'Alpaca',
    image: 'https://example.com/alpaca.jpg',  // Replace with actual alpaca image URL
    trivia: 'Alpacas are generally smaller and have softer wool than llamas.',
  };

  return (
    <div className="App">
      <h1>Camelid Comparison</h1>
      <Camelid name={llama.name} image={llama.image} trivia={llama.trivia} />
      <Camelid name={alpaca.name} image={alpaca.image} trivia={alpaca.trivia} />
    </div>
  );
}

export default App;
